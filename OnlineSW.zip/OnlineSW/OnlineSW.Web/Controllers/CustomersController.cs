﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OnlineSW.Web.Data;
using OnlineSW.Web.Models;
using OnlineSW.Web.Models.Entities;


namespace OnlineSW.Web.Controllers
{
    public class CustomersController : Controller
    {
        private readonly ApplicationDbContext dbContext;

        public CustomersController(ApplicationDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Add(AddProductViewModel viewModel)
        {
            var customer = new Customer
            {
                Name = viewModel.Name,
                Email = viewModel.Email,
                Phone = viewModel.Phone,
                Price = viewModel.Price,
                ImageUrl=viewModel.ImageUrl,
            };
            await dbContext.Customers.AddAsync(customer);
            await dbContext.SaveChangesAsync();

            return RedirectToAction("List", "Customers");
        }


        [HttpGet]

        public async Task<IActionResult> List()
        {
            var Customer = await dbContext.Customers.ToListAsync();
            return View(Customer);
        }
        [HttpGet]

        public async Task<IActionResult> Edit(int id)
        {
            var customer = await dbContext.Customers.FindAsync(id);

            return View(customer);
        }

        [HttpPost]

        public async Task<IActionResult> Edit(Customer viewModel)
        {
            var customer = await dbContext.Customers.FindAsync(viewModel.Id);

            if (customer is not null)
            {
                customer.Id = viewModel.Id;
                customer.Name = viewModel.Name;
                customer.Email = viewModel.Email;
                customer.Phone = viewModel.Phone;
                customer.Price = viewModel.Price;
                customer.ImageUrl = viewModel.ImageUrl;
            }
            
            await dbContext.SaveChangesAsync();
            return RedirectToAction("List", "Customers");
        }

        [HttpPost]
        public async Task<IActionResult> Delete(Customer viewModel)
        {
            var customer = await dbContext.Customers.AsNoTracking().FirstOrDefaultAsync(x => x.Id == viewModel.Id);
            if (customer is not null)
            {
                dbContext.Customers.Remove(viewModel);
                await dbContext.SaveChangesAsync();
            }
            return RedirectToAction("List", "Customers");
        }

    }
}
